(function () {
	var e = new horde.Engine();
	e.run();
}());
